-- Supabase schema for online membership gate
create extension if not exists pgcrypto with schema extensions;

create table if not exists public.site_admins (
  user_id uuid primary key references auth.users(id) on delete cascade
);
create table if not exists public.site_settings (
  id integer primary key default 1 check (id = 1),
  group_name text not null default 'الجروب',
  group_url text not null default 'https://t.me/',
  support_url text not null default 'https://t.me/mshw21',
  rules text not null default 'الاشتراك شخصي. ممنوع مشاركة الأكواد أو تسريب المحتوى.'
);
insert into public.site_settings(id) values (1) on conflict (id) do nothing;

create table if not exists public.subscription_codes (
  id uuid primary key default gen_random_uuid(),
  code_hash text not null unique,
  code_display text not null unique,
  used boolean not null default false,
  used_by_name text,
  used_at timestamptz,
  created_at timestamptz not null default now()
);

alter table public.site_admins enable row level security;
alter table public.site_settings enable row level security;
alter table public.subscription_codes enable row level security;
revoke all on public.site_admins, public.site_settings, public.subscription_codes from anon, authenticated;
grant select, insert, update, delete on public.site_admins, public.site_settings, public.subscription_codes to service_role;

create or replace function public.is_site_admin()
returns boolean language sql stable security definer set search_path = public, auth
as $$ select exists(select 1 from public.site_admins where user_id = auth.uid()); $$;
revoke all on function public.is_site_admin() from public;
grant execute on function public.is_site_admin() to authenticated;

create or replace function public.public_site_settings()
returns jsonb language sql stable security definer set search_path = public
as $$ select jsonb_build_object('group_name',group_name,'group_url',group_url,'support_url',support_url,'rules',rules) from public.site_settings where id=1; $$;
grant execute on function public.public_site_settings() to anon, authenticated;

create or replace function public.admin_get_settings()
returns jsonb language plpgsql security definer set search_path = public
as $$
begin
 if not public.is_site_admin() then raise exception 'not authorized'; end if;
 return (select jsonb_build_object('group_name',group_name,'group_url',group_url,'support_url',support_url,'rules',rules) from public.site_settings where id=1);
end; $$;
grant execute on function public.admin_get_settings() to authenticated;

create or replace function public.admin_update_settings(p_group_name text,p_group_url text,p_support_url text,p_rules text)
returns boolean language plpgsql security definer set search_path = public
as $$
begin
 if not public.is_site_admin() then raise exception 'not authorized'; end if;
 if length(trim(coalesce(p_group_name,'')))=0 or p_group_url !~ '^https?://' or (coalesce(p_support_url,'')<>'' and p_support_url !~ '^https?://') then raise exception 'invalid input'; end if;
 update public.site_settings set group_name=trim(p_group_name),group_url=trim(p_group_url),support_url=trim(coalesce(p_support_url,'')),rules=coalesce(p_rules,'') where id=1;
 return true;
end; $$;
grant execute on function public.admin_update_settings(text,text,text,text) to authenticated;

create or replace function public.admin_add_subscription_code(p_code text)
returns jsonb language plpgsql security definer set search_path = public, extensions
as $$
declare c text:=upper(trim(coalesce(p_code,'')));
begin
 if not public.is_site_admin() then raise exception 'not authorized'; end if;
 if c !~ '^[A-Z0-9]{4}-[A-Z0-9]{4}$' then return jsonb_build_object('ok',false,'message','صيغة الكود لازم تكون XXXX-XXXX.'); end if;
 insert into public.subscription_codes(code_hash,code_display) values (encode(extensions.digest(c,'sha256'),'hex'),c);
 return jsonb_build_object('ok',true);
exception when unique_violation then return jsonb_build_object('ok',false,'message','الكود موجود بالفعل.');
end; $$;
grant execute on function public.admin_add_subscription_code(text) to authenticated;

create or replace function public.admin_list_subscription_codes()
returns table(code text,used boolean) language plpgsql security definer set search_path = public
as $$
begin
 if not public.is_site_admin() then raise exception 'not authorized'; end if;
 return query select code_display,subscription_codes.used from public.subscription_codes order by created_at desc;
end; $$;
grant execute on function public.admin_list_subscription_codes() to authenticated;

create or replace function public.admin_delete_subscription_code(p_code text)
returns boolean language plpgsql security definer set search_path = public, extensions
as $$
begin
 if not public.is_site_admin() then raise exception 'not authorized'; end if;
 delete from public.subscription_codes where code_hash=encode(extensions.digest(upper(trim(p_code)),'sha256'),'hex');
 return true;
end; $$;
grant execute on function public.admin_delete_subscription_code(text) to authenticated;

create or replace function public.redeem_subscription_code(p_code text,p_name text)
returns jsonb language plpgsql security definer set search_path = public, extensions
as $$
declare c text:=upper(trim(coalesce(p_code,''))); n text:=left(trim(coalesce(p_name,'')),60); rec public.subscription_codes%rowtype; cfg public.site_settings%rowtype;
begin
 if n='' or c='' then return jsonb_build_object('ok',false,'message','اكتب الاسم والكود.'); end if;
 select * into rec from public.subscription_codes where code_hash=encode(extensions.digest(c,'sha256'),'hex') and used=false for update;
 if not found then return jsonb_build_object('ok',false,'message','الكود غير صحيح أو تم استخدامه بالفعل.'); end if;
 update public.subscription_codes set used=true,used_by_name=n,used_at=now() where id=rec.id;
 select * into cfg from public.site_settings where id=1;
 return jsonb_build_object('ok',true,'group_name',cfg.group_name,'group_url',cfg.group_url);
end; $$;
grant execute on function public.redeem_subscription_code(text,text) to anon, authenticated;
